import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Izuku
 extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public Izuku() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
      
      btnCharacter = new JButton("Character");
      btnCharacter.setPreferredSize(buttonSize);
      btnCharacter.addActionListener(this);
      
      btnNew = new JButton("New");
      btnNew.setPreferredSize(buttonSize);
      btnNew.addActionListener(this);
      
      btnDelete = new JButton("Back");
      btnDelete.setPreferredSize(buttonSize);
      btnDelete.addActionListener(this);
      
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      btnPanel.add(btnCharacter);
      btnPanel.add(btnNew);
      btnPanel.add(btnDelete);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("HERObac.png");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("Izuku.jpg");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         //Not done
         System.out.println("Back testing");
      } else if (e.getSource() == btnCharacter) {
         //Not done
         System.out.println("Character testing");
      } else if (e.getSource() == btnNew) {
         //Not done
         System.out.println("New testing");
      } else if (e.getSource() == btnDelete) {
         //Not done
         System.out.println("Delete testing");
      }
   }
   
   //The main() method 
   public static void main(String[] args) {
      Izuku app = new Izuku();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("My Hero Academia", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Midoria is a protagonist that is willing to help any random person.", 230, 55);
         g.drawString("He is a inheritor of One for All from All Might who is the ", 230, 75);
         g.drawString("number one hero.", 230, 95);
         g.drawString("Midoria has a ability called Full Cowling which boosts all his powers.", 230, 115);
         g.drawString("Power Level: High 7-A: Large Mountain level", 230, 135);
          
          

 


      }
   }
}