import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Ayano
 extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public Ayano() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
      
      btnCharacter = new JButton("Character");
      btnCharacter.setPreferredSize(buttonSize);
      btnCharacter.addActionListener(this);
      
      btnNew = new JButton("New");
      btnNew.setPreferredSize(buttonSize);
      btnNew.addActionListener(this);
      
      btnDelete = new JButton("Back");
      btnDelete.setPreferredSize(buttonSize);
      btnDelete.addActionListener(this);
      
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      btnPanel.add(btnCharacter);
      btnPanel.add(btnNew);
      btnPanel.add(btnDelete);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("COTEbac.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("ayano.jpg");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         System.out.println("Back testing");
         this.dispose();
         classroomOfTheEliteGUI app = new classroomOfTheEliteGUI();
      } else if (e.getSource() == btnCharacter) {
         //Not done
         System.out.println("Character testing");
      } else if (e.getSource() == btnNew) {
         //Not done
         System.out.println("New testing");
      } else if (e.getSource() == btnDelete) {
         //Not done
         System.out.println("Delete testing");
      }
   }
   
   //The main() method 
   public static void main(String[] args) {
      Ayano app = new Ayano();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.WHITE);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Kiyotaka Ayanokoji", 230, 35);
         
         //Description
         g.setColor(Color.WHITE);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Anime: Classroom of the Elite", 230, 75);
         g.drawString("Ayanokoji is orginally portrayed as an ordinary student.", 230, 95);
         g.drawString("Only later on are we aware he is not as ordinary as you think he is.", 230, 115);
         g.drawString("Ayanokoji is the type of protagonist that thinks of people as tools", 230, 135);
         g.drawString("and he doesn't care what he has to do as long as he wins.", 230, 155);
         g.drawString("At the tender age of 4 he had a record of 127 wins against people older than him.", 230, 175);
         g.drawString("Power-Level: 9-B: Street level", 230, 195);
         
         
      }
   }
}