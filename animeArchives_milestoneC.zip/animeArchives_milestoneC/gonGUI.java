import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class gonGUI extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public gonGUI() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
            
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("hunter.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("gon.png");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            Image attack = tk.getImage("gonpunch.jpg");
            g.drawImage(attack, getWidth() - 400, 190, 250, 130, this);       
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         System.out.println("Back testing");
         this.dispose();
         hunterxhunterGUI app = new hunterxhunterGUI();
      }
   }
   
   //The main() method 
   public static void main(String[] args) {
      gonGUI app = new gonGUI();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Gon Freecss", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Greatest Feat: : Eren possesses the power of the Attack Titan, which", 230, 55);
         g.drawString("grants him the ability to transform into a powerful Titan form. This", 230, 75);
         g.drawString("transformation grants him immense strength, endurance, and", 230, 95);
         g.drawString("regenerative abilities, enabling him to engage in battles against", 230, 115);
         g.drawString("other Titans.Can destroy a building with a single strike.", 230, 135);
         g.drawString("Power Level: 7-B: City level", 230, 155);
      }
   }
}