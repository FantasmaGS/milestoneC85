import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Natsu
 extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public Natsu() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
      
      btnCharacter = new JButton("Character");
      btnCharacter.setPreferredSize(buttonSize);
      btnCharacter.addActionListener(this);
      
      btnNew = new JButton("New");
      btnNew.setPreferredSize(buttonSize);
      btnNew.addActionListener(this);
      
      btnDelete = new JButton("Back");
      btnDelete.setPreferredSize(buttonSize);
      btnDelete.addActionListener(this);
      
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      btnPanel.add(btnCharacter);
      btnPanel.add(btnNew);
      btnPanel.add(btnDelete);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("Fairybac.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("natsu.jpg");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         System.out.println("Back testing");
         this.dispose();
         fairyTailGUI app = new fairyTailGUI();
      } else if (e.getSource() == btnCharacter) {
         //Not done
         System.out.println("Character testing");
      } else if (e.getSource() == btnNew) {
         //Not done
         System.out.println("New testing");
      } else if (e.getSource() == btnDelete) {
         //Not done
         System.out.println("Delete testing");
      }
   }
   
   //The main() method 
   public static void main(String[] args) {
      Natsu app = new Natsu();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Natsu Dragneel", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Anime: Fairy Tail", 230, 75);
         g.drawString("Natsu is the son Igneel, a fire dragon and he is also a fire dragon slayer.", 230, 95);
         g.drawString("He is the main protagonist of Fairy Tail and is capable of sending fire through space.", 230, 115);
         g.drawString("Natsu is the type of protagonist that believes in the power of friendship.", 230, 135);
         g.drawString("Power level: 5-A: Large Planet level", 230, 155);
      }
   }
}