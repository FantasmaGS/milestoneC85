import java.net.URI;
import java.util.HashMap;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class attackOnTitansGUI extends JFrame implements ActionListener, ListSelectionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
    private LabelComponent labelComponent;
    private JList<String> characterList;
    private DefaultListModel<String> listModel;
    private HashMap<String, String> reviewWebsiteMap;

   public attackOnTitansGUI() {
      // Create buttons
        Dimension buttonSize = new Dimension(100, 30);
        btnBack = new JButton("Back");
        btnBack.setPreferredSize(buttonSize);
        btnBack.addActionListener(this);

        btnCharacter = new JButton("Character");
        btnCharacter.setPreferredSize(buttonSize);
        btnCharacter.addActionListener(this);

        btnNew = new JButton("New");
        btnNew.setPreferredSize(buttonSize);
        btnNew.addActionListener(this);

        btnDelete = new JButton("Delete");
        btnDelete.setPreferredSize(buttonSize);
        btnDelete.addActionListener(this);
        
        // Initialize reviewWebsiteMap
        reviewWebsiteMap = new HashMap<>();
        reviewWebsiteMap.put("IMDb: 7.7/10", "https://www.imdb.com/title/tt2013293/?ref_=nv_sr_srsg_0_tt_8_nm_0_q_The%2520wind%2520rise");
        reviewWebsiteMap.put("Review 2", "http://www.website2.com");
        reviewWebsiteMap.put("Review 3", "http://www.website3.com");

        // Create the list model and list
        listModel = new DefaultListModel<>();
        listModel.addElement("IMDb: 7.7/10");
        listModel.addElement("Review 2");
        listModel.addElement("Review 3");
        characterList = new JList<>(listModel);
        characterList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        characterList.setLayoutOrientation(JList.VERTICAL);
        characterList.setOpaque(false);
        characterList.setBackground(new Color(0, 0, 0, 123)); // Colour for the Half transparent background
        characterList.addListSelectionListener(this);
        characterList.setForeground(Color.WHITE);

        // Create the label component
        labelComponent = new LabelComponent();

        // A Nested layout (it means a layout inside a layout)
        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.setOpaque(false);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setOpaque(false);
        btnPanel.add(btnBack);
        btnPanel.add(btnCharacter);
        btnPanel.add(btnNew);
        btnPanel.add(btnDelete);

        // Create a scroll pane for the character list
         JScrollPane listScrollPane = new JScrollPane(characterList);
         listScrollPane.setPreferredSize(new Dimension(475, 100)); // Adjust the size here
         listScrollPane.setOpaque(false);
         listScrollPane.getViewport().setOpaque(false); // Making JScrollPane transparent
         
         JPanel listPanel = new JPanel();
         listPanel.setOpaque(false);
         listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
         listPanel.add(Box.createVerticalStrut(220));  // Add a vertical margin
         listPanel.add(listScrollPane);
         listPanel.add(Box.createVerticalGlue());

        // Add btnPanel to buttonPanel
        buttonPanel.add(btnPanel, BorderLayout.CENTER);

      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("titan.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("attack.jpg");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
        picturesPanel.add(labelComponent, BorderLayout.CENTER);
        picturesPanel.add(listPanel, BorderLayout.EAST);

        setContentPane(picturesPanel);

        setTitle("Animes Archives");
        setSize(720, 405);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBack) {
            System.out.println("Back exe.");
            this.dispose();
            new animeList();
        } else if (e.getSource() == btnCharacter) {
            System.out.println("Character testing");
            this.dispose();
            erenGUI app = new erenGUI();
        } else if (e.getSource() == btnNew) {
            //Not done
            System.out.println("New testing");
        } else if (e.getSource() == btnDelete) {
            //Not done
            System.out.println("Delete testing");
        }
    }
    
    public void valueChanged(ListSelectionEvent e) {
    if (!e.getValueIsAdjusting()) {
        String selectedReview = characterList.getSelectedValue();
        System.out.println("Review selected: " + selectedReview);

        // Open a website
        try {
            // Assume a mapping from selected review to a URL
            String url = reviewWebsiteMap.get(selectedReview);

            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
   
   //The main() method 
   public static void main(String[] args) {
      attackOnTitansGUI app = new attackOnTitansGUI();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Attack On Titan", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Description: After his hometown is destroyed and his mother is killed, young ", 230, 55);
         g.drawString("Eren Jaeger vowsto cleanse the earth of the giant humanoid Titans that have", 230, 75);
         g.drawString("brought humanity to the brink of extinction brink of extinction.", 230, 95);
         g.drawString("Aired: Apr 7, 2013 to Present", 230, 125);
         g.drawString("Producers: Production I.G, Dentsu, Mainichi Broadcasting System", 230, 145);
         g.drawString("Studios: Wit Studio", 230, 165);
         g.drawString("Genres: Action, Award Winning, Drama, Suspense", 230, 185);
         g.drawString("Rating: R - 17+ (violence & profanity)", 230, 205);
      }
   }
}