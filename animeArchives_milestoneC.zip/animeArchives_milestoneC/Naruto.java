import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Naruto
 extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public Naruto() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
      
      btnCharacter = new JButton("Character");
      btnCharacter.setPreferredSize(buttonSize);
      btnCharacter.addActionListener(this);
      
      btnNew = new JButton("New");
      btnNew.setPreferredSize(buttonSize);
      btnNew.addActionListener(this);
      
      btnDelete = new JButton("Back");
      btnDelete.setPreferredSize(buttonSize);
      btnDelete.addActionListener(this);
      
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("Narutobac.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("Naruto.jpg");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         System.out.println("Back testing");
         this.dispose();
         narutoShipuddenGUI app = new narutoShipuddenGUI();
      } 
   }
   
   //The main() method 
   public static void main(String[] args) {
      Naruto app = new Naruto();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Naruto Uzumaki", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Anime: Naruto Shippuuden", 230, 55);
         g.drawString("Naruto is the son of the Fourth Hokage and has the Ninetales sealed in him.", 230, 75);
         g.drawString("Despite having immense powers, he is the type of protagonist to give second chances.", 230, 95);
         g.drawString("His Baryon mode can steal enemy�s life away and increases the damage output at least 5x times.", 230, 115);
         g.drawString("Power Level: Low 5-B: Small Planet level", 230, 135);


      }
   }
}