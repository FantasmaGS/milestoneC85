import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class spikeGUI extends JFrame implements ActionListener {
   private JButton btnBack, btnCharacter, btnNew, btnDelete;
   private LabelComponent labelComponent;

   public spikeGUI() {
      // Create buttons
      Dimension buttonSize = new Dimension(100, 30);
      btnBack = new JButton("Back");
      btnBack.setPreferredSize(buttonSize);
      btnBack.addActionListener(this);
            
      // Create the label component
      labelComponent = new LabelComponent();

      // A Nested layout(it means a layout inside a layout)  
      JPanel buttonPanel = new JPanel(new BorderLayout());
      buttonPanel.setOpaque(false);
      
      JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      btnPanel.setOpaque(false);
      btnPanel.add(btnBack);
      
      // Add btnPanel to buttonPanel
      buttonPanel.add(btnPanel, BorderLayout.CENTER);
      
      JPanel picturesPanel = new JPanel(new BorderLayout()) {
         @Override
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image backgoundImg = tk.getImage("piece.jpg");
            g.drawImage(backgoundImg, 0, 0, getWidth(), getHeight(), this);
            
            Image poster = tk.getImage("spike (1).png");
            g.drawImage(poster, getWidth() - 690, 20, 200, 300, this);
            
            Image attack = tk.getImage("spiegal.jpg");
            g.drawImage(attack, getWidth() - 400, 190, 250, 130, this);       
            
            // Draw the labels
            labelComponent.paintComponent(g);
         }//end paint
      };
      
      picturesPanel.add(buttonPanel, BorderLayout.SOUTH);
      picturesPanel.add(labelComponent, BorderLayout.CENTER);
      
      setContentPane(picturesPanel);
      
      setTitle("Animes Archives");
      setSize(720, 405);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == btnBack) {
         System.out.println("Back testing");
         this.dispose();
         cowboyBebopGUI app = new cowboyBebopGUI();
      }
   }
   
   //The main() method 
   public static void main(String[] args) {
      spikeGUI app = new spikeGUI();
   }

   private static class LabelComponent extends JComponent {
      @Override
      protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         
         // Draw the labels at specific positions
         //Title
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 25));
         g.drawString("Spike", 230, 35);
         
         //Description
         g.setColor(Color.BLACK);
         g.setFont(new Font("Arial", Font.BOLD, 12));
         g.drawString("Greatest Feat: Won a battle with a strong cyborg that can fly around and has", 230, 55);
         g.drawString("a built-in energy shield.", 230, 75);
         g.drawString("Power Level: High 8-C: Large Building level", 230, 115);
      }
   }
}